from flask import Flask, render_template, request

app = Flask(__name__)

# Lista de contactos (inicialmente vacía)
contactos = []

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        nombre = request.form["nombre"]
        telefono = request.form["telefono"]
        contacto = {"nombre": nombre, "telefono": telefono}
        contactos.append(contacto)
    return render_template("index.html", contactos=contactos)

if __name__ == "_main_":
    app.run(debug=True)