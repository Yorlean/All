from functools import reduce
def contar(n):
    return n > num
num =int(input("Ingrese un numero:"))
lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
mayores = list(filter(contar, lista))
print(mayores)
cantidad= reduce((lambda x, y: y, lista))
print(cantidad)