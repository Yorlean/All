from functools import reduce
suma = reduce((lambda x, y: x + y), [1, 2, 3, 4, 5, 6])
print(suma)