from functools import reduce
numero_max = reduce(lambda x, y: y, [1, 2, 3, 4, 5, 6])
print(numero_max)