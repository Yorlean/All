valor_a = 5
valor_lista = [4, 8, 24, 29, 100]
print (valor_lista[3])