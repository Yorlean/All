from functools import reduce
producto = reduce((lambda x, y: x * y), [1, 2, 3, 4])
print (producto)