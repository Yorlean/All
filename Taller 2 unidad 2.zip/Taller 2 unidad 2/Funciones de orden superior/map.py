def cuadradro(numero):
    return numero * numero

lista = [1, 2, 3, 4, 5]
resultado = map(cuadradro, lista)

lista_resultado = list(resultado)
print(lista_resultado)