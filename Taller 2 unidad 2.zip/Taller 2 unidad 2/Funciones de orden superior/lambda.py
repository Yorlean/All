def mi_funcion(lambda_font):
    return lambda_font(2, 4)

resultado= mi_funcion(lambda a, b: a + b)
print(resultado)