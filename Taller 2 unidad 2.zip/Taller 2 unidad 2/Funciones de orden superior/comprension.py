#         0     1     2        3        4       5      6
lista2 =["Yo", "soy", "un", "estudiante", "muy", "bueno"]
print(lista2)

lista2.append("inteligente")
print(lista2)

lista2.pop()
print(lista2)

lista2.clear()
print(lista2)